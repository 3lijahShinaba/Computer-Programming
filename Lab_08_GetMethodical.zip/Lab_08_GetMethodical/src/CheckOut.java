import java.util.Scanner;

public class CheckOut {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double totalCost = 0.0;

        while (true) {
            double price = getRangedDouble(scanner, "Enter the price of your item ($0.50 - $9.99):", 0.50, 9.99);
            totalCost += price;

            char moreItems = getYNConfirm(scanner, "Do you have more items to add (Y/N)?");
            if (moreItems != 'Y') {
                break;
            }
        }

        System.out.printf("Total cost of items: $%.2f%n", totalCost);

        scanner.close();
    }

    // Method to get a valid double input within a specified range
    public static double getRangedDouble(Scanner scanner, String prompt, double min, double max) {
        double value = 0.0;
        boolean validInput = false;

        while (!validInput) {
            System.out.print(prompt);
            if (scanner.hasNextDouble()) {
                value = scanner.nextDouble();
                if (value >= min && value <= max) {
                    validInput = true;
                } else {
                    System.out.println("Invalid input. Please enter a number between " + min + " and " + max + ".");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid double.");
                scanner.next(); // Clear the invalid input
            }
        }

        return value;
    }

    // Method to get a yes/no confirmation from the user
    public static char getYNConfirm(Scanner scanner, String prompt) {
        char response = 'a';
        boolean validInput = false;

        while (!validInput) {
            System.out.print(prompt);
            String input = scanner.next().toUpperCase();
            if (input.length() == 1) {
                response = input.charAt(0);
                if (response == 'Y' || response == 'N') {
                    validInput = true;
                } else {
                    System.out.println("Invalid input. Please enter 'Y' or 'N'.");
                }
            } else {
                System.out.println("Invalid input. Please enter 'Y' or 'N'.");
            }
        }

        return response ;
    }
}

