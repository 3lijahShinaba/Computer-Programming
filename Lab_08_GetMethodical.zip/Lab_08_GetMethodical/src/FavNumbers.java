import java.util.Scanner;

public class FavNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int favoriteInt;
        double favoriteDouble;

        // Prompt for favorite integer
        System.out.print("Enter your favorite integer: ");
        favoriteInt = getInt(scanner);

        // Prompt for favorite double
        System.out.print("Enter your favorite double: ");
        favoriteDouble = getDouble(scanner);

        System.out.println("Your favorite integer is: " + favoriteInt);
        System.out.println("Your favorite double is: " + favoriteDouble);

        scanner.close();
    }

    // Method to get a valid integer input
    public static int getInt(Scanner scanner) {
        int value = 0;
        boolean validInput = false;

        while (!validInput) {
            if (scanner.hasNextInt()) {
                value = scanner.nextInt();
                validInput = true;
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next(); // Clear the invalid input
            }
        }

        return value;
    }

    // Method to get a valid double input
    public static double getDouble(Scanner scanner) {
        double value = 0.0;
        boolean validInput = false;

        while (!validInput) {
            if (scanner.hasNextDouble()) {
                value = scanner.nextDouble();
                validInput = true;
            } else {
                System.out.println("Invalid input. Please enter a valid double.");
                scanner.next(); // Clear the invalid input
            }
        }

        return value;
    }
}

