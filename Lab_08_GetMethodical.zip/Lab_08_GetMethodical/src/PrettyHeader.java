public class PrettyHeader {
    public static void main(String[] args) {
        SafeInput.prettyHeader("Message Centered Here");
    }
}

class SafeInput {
    public static void prettyHeader(String msg) {
        int totalWidth = 60;
        int msgWidth = msg.length();
        int sideStars = (totalWidth - msgWidth - 6) / 2; // Calculate the number of stars on each side of the message

        // Top row of stars
        for (int i = 0; i < totalWidth; i++) {
            System.out.print("*");
        }
        System.out.println(); // Move to the next line

        // Second row with centered message
        System.out.print("***");
        for (int i = 0; i < sideStars; i++) {
            System.out.print(" ");
        }
        System.out.print(msg);
        for (int i = 0; i < sideStars; i++) {
            System.out.print(" ");
        }
        if (msgWidth % 2 != 0) {
            System.out.print(" "); // Add an extra space if the message length is odd
        }
        System.out.println("***");

        // Bottom row of stars
        for (int i = 0; i < totalWidth; i++) {
            System.out.print("*");
        }
        System.out.println(); // Move to the next line
    }
}
