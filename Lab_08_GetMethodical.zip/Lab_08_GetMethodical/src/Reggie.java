import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Reggie {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Test SSN pattern: \\d{3}-\\d{2}-\\d{4}
        System.out.print("Enter a Social Security Number (e.g., 123-45-6789): ");
        String ssnInput = scanner.nextLine();
        String ssnPattern = "\\d{3}-\\d{2}-\\d{4}";
        boolean isSSNValid = getRegExString(ssnInput, ssnPattern);

        if (isSSNValid) {
            System.out.println("Valid SSN: " + ssnInput);
        } else {
            System.out.println("Invalid SSN: " + ssnInput);
        }

        // Test UC Student M number pattern: (M|m)\\d{5}
        System.out.print("Enter a UC Student M number (e.g., M12345): ");
        String mNumberInput = scanner.nextLine();
        String mNumberPattern = "(M|m)\\d{5}";
        boolean isMNumberValid = getRegExString(mNumberInput, mNumberPattern);

        if (isMNumberValid) {
            System.out.println("Valid UC Student M number: " + mNumberInput);
        } else {
            System.out.println("Invalid UC Student M number: " + mNumberInput);
        }

        // Test menu choice pattern: [OoSsVvQq]
        System.out.print("Enter a menu choice (O, S, V, or Q): ");
        String menuChoiceInput = scanner.nextLine();
        String menuChoicePattern = "[OoSsVvQq]";
        boolean isMenuChoiceValid = getRegExString(menuChoiceInput, menuChoicePattern);

        if (isMenuChoiceValid) {
            System.out.println("Valid menu choice: " + menuChoiceInput);
        } else {
            System.out.println("Invalid menu choice: " + menuChoiceInput);
        }

        scanner.close();
    }

    // Method to check if a given input matches a regular expression pattern
    private static boolean getRegExString(String input, String pattern) {
        Pattern regexPattern = Pattern.compile(pattern);
        Matcher matcher = regexPattern.matcher(input);
        return matcher.matches();
    }
}
