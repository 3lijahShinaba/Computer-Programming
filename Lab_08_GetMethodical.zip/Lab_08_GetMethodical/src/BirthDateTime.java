import java.util.Scanner;

public class BirthDateTime {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int year = getRangedInt(scanner, "Enter the year of birth (1950-2010):", 1950, 2010);
        int month = getRangedInt(scanner, "Enter the month of birth (1-12):", 1, 12);

        int maxDays;
        switch (month) {
            case 4:
            case 6:
            case 9:
            case 11:
                maxDays = 30;
                break;
            case 2:
                maxDays = isLeapYear(year) ? 29 : 28;
                break;
            default:
                maxDays = 31;
                break;
        }

        int day = getRangedInt(scanner, "Enter the day of birth (1-" + maxDays + "):", 1, maxDays);
        int hours = getRangedInt(scanner, "Enter the hour of birth (1-24):", 1, 24);
        int minutes = getRangedInt(scanner, "Enter the minutes of birth (1-59):", 1, 59);

        System.out.println("Date and Time of Birth: " + year + "-" + month + "-" + day + " " + hours + ":" + minutes);

        scanner.close();
    }

    // Method to get a valid integer input within a specified range
    public static int getRangedInt(Scanner scanner, String prompt, int min, int max) {
        int value = 0;
        boolean validInput = false;

        while (!validInput) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                value = scanner.nextInt();
                if (value >= min && value <= max) {
                    validInput = true;
                } else {
                    System.out.println("Invalid input. Please enter a number between " + min + " and " + max + ".");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next(); // Clear the invalid input
            }
        }

        return value;
    }

    // Method to check if a year is a leap year
    public static boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
}

